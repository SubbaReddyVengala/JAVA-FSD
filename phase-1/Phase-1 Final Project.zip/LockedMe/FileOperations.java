package com.LockedMe;
import java.io.*;
import java.util.*;
public class FileOperations {
	
public static void Creating_Directory(String dir)throws IOException
{
	File f=new File(dir);
	if(!f.exists()) {
		
		f.mkdirs();	
		}
}
public static void CreateFile(String add) 
{ 
	   File a=new File("./Directory/"+add);
    try {
     if(a.createNewFile())
     {
    	 System.out.println(a+" file created successfully !!!");  
	}
     else
     {
    	 System.out.println("Failed to create new file");
     }
    }
     catch (IOException e) {
	e.printStackTrace();	
	}
   

}
public static void DeleteFile(String del)
{
	File f=new File("./Directory/"+del);
	try {
		if(f.delete())
		{
			System.out.println(f+ " file deleted sucessfully !!!");
		}
		else
		{
			System.out.println("File Not Found");
		}
	} catch (Exception e) {
		e.printStackTrace();	}
	
}

public static void SearchFile(String search)
{
	try {
		File dir=new File("Directory");
		File[] files =dir.listFiles();
		for(File f:files)
		{
			if(f.getName().equals(search))
			{
				System.out.println(search+" found at "+f.getAbsolutePath());
				return;
			}
			
		}
	}
	catch(Exception e)
	{
	e.printStackTrace();	
	}
}
public static void DisplayFiles()
{
	try {
		File dir=new File("Directory");
		File[] file=dir.listFiles();
		for(File f:file)
		{
			System.out.println(f.getName());
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
}
}
