package com.LockedMe;
import java.util.*;
public class Navigation{
public static void handle_MenuOptions_Operations()
{ 
  Scanner sin=new Scanner(System.in);
  int ch;
 
	while(true)
	{
	try
	{    Menu.MenuOptions();
		System.out.println("Please enter your choice from the above MAIN MENU");
		ch=sin.nextInt();
		switch(ch)
		{
		case 1:
			 FileOperations.DisplayFiles();
			break;
			
		case 2: 
			Menu.MenuItems();
			handle_MenuItems_Operations();
			break;
		case 3:
			sin.close();
			System.out.println("Exited from the Application");
			System.out.println("----------------> Thank You For using this Application------------------>");
			System.exit(0);
			break;
		default:
			System.out.println("Please Enter a valid Choice From (1,2,3)");
			
			
		}
	}
	catch(Exception e)
	{
		System.out.println(e.getClass().getName());
		handle_MenuOptions_Operations();
	}

	}
}

public static void handle_MenuItems_Operations()
{ 
  Scanner sin=new Scanner(System.in);
  int ch1;
	while(true)
	{
	try
	{   
		System.out.println("Please enter your choice from the above BUSINESS OPERATIONS:");
		ch1=sin.nextInt();
		switch(ch1)
		{
		case 1:
			System.out.println("Enter a file name  to add to the Directory :");
			String a=sin.next();
			FileOperations.CreateFile(a);
			break;
		case 2: 
			System.out.println("Enter a file name  to delete from the Directory :");
			String b=sin.next();
			FileOperations.DeleteFile(b);
		    break;
		case 3:
			System.out.println("Enter a file name  to search from the Directory :");
			String c=sin.next();
			FileOperations.SearchFile(c);
			break;
		case 4:
			return;
		case 5:
			sin.close();
			System.out.println("Exited from the Application");
			System.out.println("-------------->Thank You For using this Application ------------->");
			System.exit(0);
			break;
		default:
			System.out.println("Please Enter a valid Choice From (1,2,3,4,5)");
			Menu.MenuItems();
			
		}
	}
	catch(Exception e)
	{
		System.out.println(e.getClass().getName());
		handle_MenuItems_Operations();
	}

	}
}
}

