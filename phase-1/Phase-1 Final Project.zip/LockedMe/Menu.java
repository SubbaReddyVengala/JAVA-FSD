package com.LockedMe;
public class Menu {
public static void Welcome_Screen()
{
	System.out.println("      //***************************************************//\n"
	           +"              VIRTUAL KEY FOR YOUR REPOSITORY\n"
	           +"     //****************************************************//\n");
	System.out.println("<<<<<<<<-------This Project is Developed by VENGALA SUBBA REDDY ----->>>>>>>");
	System.out.println("\n");
	
	
}
public static void MenuOptions()
{
	System.out.println("<<-------------------------------------------------------------->>");
	System.out.println("        1.Retrieving the file names in an ascending order.\n"
			           +"        2.Business-level operations.\n"
			           +"        3.Exit from the Application.");
	System.out.println("<<-------------------------------------------------------------->>");
	
}
public static void MenuItems()
{
	System.out.println("<<-------------------------------------------------------------->>");
	System.out.println("BUSINESS LEVEL OPERATIONS:");
	System.out.println("        1.TO add a user specified file to the application.\n"
			           +"        2.To delete a user specified file from the application.\n"
			           +"        3.To search a user specified file from the application\n"
			           +"        4.To return to the main context\n"
			           +"        5.Exit from the Application.");
	System.out.println("<<-------------------------------------------------------------->>");
	
}
}
