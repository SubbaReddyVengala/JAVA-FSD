package com.LockedMe;

import java.io.IOException;

public class Main {
public static void main(String[] args) throws IOException {
	FileOperations.Creating_Directory("Directory");
	Menu.Welcome_Screen();
	Navigation.handle_MenuOptions_Operations();
}
}
