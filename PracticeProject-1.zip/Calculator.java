package simplilearn;
import java.util.*;
public class Calculator {
	public static void main(String[] args)
	{
		Scanner sin=new Scanner(System.in);
		System.out.println("Enter two numbers:");
		double n1,n2;
		double n3=0;
		n1=sin.nextDouble();
		n2=sin.nextDouble();
		System.out.println("Enter an operator (+,-,*,/,%):");
		char ch;
		ch=sin.next().charAt(0);
		switch(ch)
		{
		//Addition
		case '+':
			n3=n1+n2;
			System.out.println(n1+" "+ch+" "+n2+" = "+n3);
			break;
		//Subraction
		case '-':
			n3=n1-n2;
		//Multiplication
		case '*':
			n3=n1*n2;
			System.out.println(n1+" "+ch+" "+n2+" = "+n3);
			break;
		//Division
		case '/':
			n3=(float)(n1/n2);
			System.out.println(n1+" "+ch+" "+n2+" = "+n3);
			break;
		//Modulo
		case '%':
			n3=n1%n2;
			System.out.println(n1+" "+ch+" "+n2+" = "+n3);
			break;
		default:
			System.out.println("-------------Invalid Operaor------------");	
		}
}
}