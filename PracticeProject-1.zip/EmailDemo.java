package com.simplilearn.email;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class EmailDemo {
	public static boolean valid(String search_email)
	{    //For Validating the Email id
		 String regex = "^(.+)@(.+)$";
		 Pattern pattern=Pattern.compile(regex);
		 Matcher matcher=pattern.matcher(search_email);
		 return matcher.matches();
		 }
	public static void main(String[] args) {
		ArrayList<String> email=new ArrayList<String>();
		//list of email Id's
		email.add("person1@email.com");
		email.add("person2@email.com");
		email.add("person3@email.com");
		email.add("person4@email.com");
		email.add("person5@email.com");
		email.add("person6@email.com");
		email.add("person.!!!*email.com");//invalid email it wont accept when we give even though it is present in the list
		Scanner sin=new Scanner(System.in);
		String search_email;//user input email ID
		int i;
		while(true) {//if the user enter enters a invalid email then whlie loop is helpful for re entering the email
		System.out.println("Enter the email to Search : \n");
		search_email=sin.nextLine();
		if(valid(search_email))
		{
			
			boolean a=email.contains(search_email);
			if(a)
			{
				System.out.println(search_email+" ======>found \n");//Email found
				
			}
			else
			{
				System.out.println("!!!!!-----Not found-----!!!!!!! \n");//if not found
				
			}
			
			}
		else
			System.out.println("<<<<<<---InValid Email ID--->>>>>.Please Enter a Valid Email Id:\n");
		}	
	}
		
	}



