package com.LIS;
import java.util.*;
public class LIS {
	public static int longestSubSeq(int subArr[],int n)
	{
		int lenArr[]=new int[n]; 
		//set all lenArr to 0
		   lenArr[0] = 1;       //subsequence ending with subArr[0] is 1

		for (int i = 1; i < n; i++) {       //ignore first character, second to all
		  for (int j = 0; j < i; j++) {     //subsequence ends with subArr[j]
		       if (subArr[j] < subArr[i] && lenArr[j] > lenArr[i])
		            lenArr[i] = lenArr[j];
		       }
		            lenArr[i]++;              //add arr[i]
		       }	
		   int lis = 0;
		   for (int i = 0; i<n; i++)      // find longest increasing subsequence
		      lis = Math.max(lis, lenArr[i]);
		   return lis;
		}
	
public static void main(String[] args) {
	Scanner sin=new Scanner(System.in);
	System.out.println("Enter the size of an Array:");
	int n;
	n=sin.nextInt();
	int arr[] = new int[n]; 
	System.out.println("Enter the elements of an array: ");
	for(int i=0;i<n;i++)
	{
		arr[i]=sin.nextInt();
		}
	System.out.println("Length of the Longest Increasing Sub Sequence:"+longestSubSeq(arr, n));
}
}
