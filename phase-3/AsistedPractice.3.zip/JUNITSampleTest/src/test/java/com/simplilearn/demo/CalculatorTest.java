package com.simplilearn.demo;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
public class CalculatorTest {
private Calculator calc;
@BeforeEach
public void setup()
{
	calc=new Calculator();
}
@AfterEach
public void tearDown()
{
	calc=null;
}
@Test
public void addTest()
{
	assertEquals(7,calc.add(4, 3));
}
@Test
public void subtest()
{
	assertEquals(9,calc.sub(12, 3));
	assertNotEquals(7,calc.sub(12, 3));
}
@Test
public void multest()
{
	assertEquals(12,calc.mul(4, 3));
	assertNotEquals(30,calc.mul(12, 3));
}
@Test
public void divtest()
{
	assertEquals(10,calc.div(100, 10));
	assertNotEquals(30,calc.div(12, 3));
}
}
