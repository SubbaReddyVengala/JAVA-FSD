package com.simplilearn.demo;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledOnOs;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

public class ConditionalTets {
@Test
@EnabledOnOs({OS.WINDOWS})
public void runOnMac()
{
	System.out.println("This runs  on MAC OS");
}
@DisabledOnOs({OS.LINUX})
public void runOnLinux()
{
	System.out.println("This Not Run on LINUX OS");
}

}
