package com.project.Authentication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
@ComponentScan("com.project.Authentication")
@SpringBootApplication
public class AuthenticationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthenticationsApplication.class, args);
	}

}
