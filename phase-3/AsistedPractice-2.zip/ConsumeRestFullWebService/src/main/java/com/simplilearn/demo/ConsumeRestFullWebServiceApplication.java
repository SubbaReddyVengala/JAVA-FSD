package com.simplilearn.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsumeRestFullWebServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsumeRestFullWebServiceApplication.class, args);
	}

}