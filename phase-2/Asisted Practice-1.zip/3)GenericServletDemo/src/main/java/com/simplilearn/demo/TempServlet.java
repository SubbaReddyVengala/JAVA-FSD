package com.simplilearn.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/temp")
public class TempServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ServletConfig config;
       
    public TempServlet() {
        super();
       
    }

	
	public void init(ServletConfig config) throws ServletException {
		
		System.out.println("Init called");
		this.config=config;
	}

	
	public void destroy() {
		config=null;
		System.out.println("Destroy Called");
	}

	
	public ServletConfig getServletConfig() {
		// TODO Auto-generated method stub
		return config;
	}


	public String getServletInfo() {
		// TODO Auto-generated method stub
		return config.getServletName(); 
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	System.out.println("Service Called");
   PrintWriter out=response.getWriter();
   out.println("This is My Servlet");
	}

}
