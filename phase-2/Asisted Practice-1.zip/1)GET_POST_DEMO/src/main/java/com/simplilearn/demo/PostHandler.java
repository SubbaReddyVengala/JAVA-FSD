package com.simplilearn.demo;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/posthandler")
public class PostHandler extends HttpServlet{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
          PrintWriter out = response.getWriter();
            out.println("<html><body>");
            out.println("From POST<br><br>");
            String name = request.getParameter("name");
            String address = request.getParameter("address");
            
            out.println("Name=" + name + "<br>Address=" + address);
            out.println("</body></html>");
}

}
